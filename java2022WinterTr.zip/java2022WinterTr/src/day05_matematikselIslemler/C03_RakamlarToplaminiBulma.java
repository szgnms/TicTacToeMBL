package day05_matematikselIslemler;

import java.util.Scanner;

public class C03_RakamlarToplaminiBulma {
    public static void main(String[] args) {

        Scanner scan=new Scanner(System.in);
        System.out.println("Lutfen dort basamakli bir sayi giriniz");
        int sayi=scan.nextInt();

        int rakam=0;
        int rakamlarToplami=0;

        rakam=sayi%10;
        rakamlarToplami +=rakam;
        sayi /=10;


        rakam=sayi%10;
        rakamlarToplami +=rakam;
        sayi /=10;

        rakam=sayi%10;
        rakamlarToplami +=rakam;
        sayi /=10;

        rakam=sayi%10;
        rakamlarToplami +=rakam;
        sayi /=10;

        System.out.println("sayi toplam" + rakamlarToplami);

    }
}
