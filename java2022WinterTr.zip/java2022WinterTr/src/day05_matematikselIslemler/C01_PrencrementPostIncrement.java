package day05_matematikselIslemler;

public class C01_PrencrementPostIncrement {
    public static void main(String[] args) {



        int sayi=10;

        sayi++;
        System.out.println(sayi);

        System.out.println(++sayi);
        System.out.println(sayi);

        System.out.println(sayi++);
        System.out.println(sayi);

    }

}
