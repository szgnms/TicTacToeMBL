package day10_switch_StringManipulation;

import java.util.Locale;

public class C04_CharAt {



    public static void main(String[] args) {




String str="Java Cok Guzel";

        System.out.println(str.charAt(0));

        System.out.println(str.charAt(9));

        System.out.println(str.charAt(5));

    }
}
