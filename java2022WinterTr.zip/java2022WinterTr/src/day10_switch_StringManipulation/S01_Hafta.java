package day10_switch_StringManipulation;

import java.util.Scanner;

public class S01_Hafta {
    public static void main(String[] args) {


        Scanner scan = new Scanner(System.in);
        System.out.println("gun girniz");
        int gun = scan.nextInt();

        switch (gun) {

            case 1:
                System.out.println("Pazartesi");
                break;
            case 2:
                System.out.println("Sali");
                break;
            case 3:
                System.out.println("Carsamba");
                break;
            case 4:
                System.out.println("Persembe");
                break;
            case 5:
                System.out.println("cuma");
                break;
            case 6:
                System.out.println("cumartesi");
                break;
            case 7:
                System.out.println("Pazar");

            default:
                System.out.println("hatali giris");
        }


    }


}
