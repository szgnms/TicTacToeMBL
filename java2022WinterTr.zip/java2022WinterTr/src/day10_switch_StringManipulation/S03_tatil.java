package day10_switch_StringManipulation;

import java.util.Locale;
import java.util.Scanner;

public class S03_tatil {
    public static void main(String[] args) {


        Scanner scan = new Scanner(System.in);
        System.out.println("gun giriniz");
        String gun = scan.nextLine().toUpperCase(Locale.ROOT);

        switch (gun) {

            case "PAZARTESI":
            case "SALI":
            case "CARSAMBA":
            case "PERSEMBE":
            case "CUMA":
                System.out.println("HAFTAICI");
                break;
            case "CUMARTESI":
            case "PAZAR":
                System.out.println("HAFTASONU");

            default:
                System.out.println("hatali giris");
        }
    }
}
