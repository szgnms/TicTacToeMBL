package day10_switch_StringManipulation;

import java.util.Scanner;

public class S04_Sdet {
    public static void main(String[] args) {


        Scanner scan = new Scanner(System.in);
        System.out.println("S. D. E. .T. harflerinden birini giriniz");
        String harf = scan.next().toUpperCase();

        switch (harf) {

            case "S":
                System.out.println("Software");
                break;
            case "D":
                System.out.println("Developer");
                break;
            case "E":
                System.out.println("Engineer");
                break;
            case "T":
                System.out.println("In Testing");
                break;
            default:
                System.out.println("yanlis giris");
        }


    }
}