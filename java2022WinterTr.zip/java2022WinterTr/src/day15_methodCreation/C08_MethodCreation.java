package day15_methodCreation;

public class C08_MethodCreation {
    public static void main(String[] args) {

        C07_MethodCreation.hosgeldinYazdir();

    }
}
