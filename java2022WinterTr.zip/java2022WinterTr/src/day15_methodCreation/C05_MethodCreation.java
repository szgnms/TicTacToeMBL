package day15_methodCreation;

public class C05_MethodCreation {
    public static void main(String[] args) {
        String str="Ali";
        C04.ucHarfiTersineCevir(str);
        str="Java";
        C04.dortHarfiTersineCevir(str);
    }
}