package day15_methodCreation;

public class C01_methodCreation {
    public static void main(String[] args) {

        String str="Java ogrenmek cok kolay";

        //str'in ilk 6 harfini almak istesek

        str.substring(0,4);




    }
}
