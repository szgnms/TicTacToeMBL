package day12_StringManipulation;

public class C05_replace {
    public static void main(String[] args) {

        String str="bugün ne çok şey öğrendik";


        System.out.println("space hariç karakter sayısı :"  +str.replace(" " , "").length());

        System.out.println("" +str.length());


        str=str.replace("bugün","yarın");
        str=str.replace("öğrendik", "öğreneceğiz");

        System.out.println(str);


        str.replace("ne çok", "ne az");

        System.out.println(str);

    }
}
