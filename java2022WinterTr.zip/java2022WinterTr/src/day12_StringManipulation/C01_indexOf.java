package day12_StringManipulation;

public class C01_indexOf {
    public static void main(String[] args) {





    }
}
