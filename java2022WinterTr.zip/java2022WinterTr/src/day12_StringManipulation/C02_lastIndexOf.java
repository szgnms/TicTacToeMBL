package day12_StringManipulation;

public class C02_lastIndexOf {
    public static void main(String[] args) {

        String str="Eclipse" ;
        System.out.println(str.lastIndexOf("p",4));




    }
}
