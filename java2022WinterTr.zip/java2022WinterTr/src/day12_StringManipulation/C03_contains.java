package day12_StringManipulation;

public class C03_contains {
    public static void main(String[] args) {

        String email = "mulkiyeayboy@gmail.com";
        String arananMetin = "@gmail.com";

        if (!email.contains(arananMetin)) {
            System.out.println("Lutfen gmail adresi giriniz");
        } else if (email.lastIndexOf(arananMetin) == (email.length() - 10)) {
            System.out.println("Email adresiniz kaydedildi");
        } else {
            System.out.println("Lutfen yazımı kontrol ediniz");

        }

    }
}
