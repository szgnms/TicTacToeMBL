package day08_ifElseIfStatements;

import java.util.Scanner;

public class C03_SayiKontrol {
    public static void main(String[] args) {

        Scanner scan=new Scanner(System.in);
        System.out.println("Lutfen iki sayi giriniz");
        double sayi1= scan.nextDouble();
        double sayi2=scan.nextDouble();

        if (sayi1>0 && sayi2>0){
            System.out.println("girdigniz iki sayida pozitif oldugundan toplamlari= " +
                    (sayi1+sayi2));
        }else if (sayi1<0 && sayi2<0){
            System.out.println("girdigniz iki sayida pozitif oldugundan toplamlari= " +
            (sayi1*sayi2));
        }else if (sayi1*sayi2<0){
            System.out.println("fakli isaretlerde sayiarla islem yapamazsin");
        }else {
            System.out.println("sifir yutan elemandir");
        }

    }
}
