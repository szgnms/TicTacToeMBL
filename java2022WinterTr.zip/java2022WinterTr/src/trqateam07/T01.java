package trqateam07;

public class T01 {

        public static void main(String[] args) {


            String str= "Tarik";

            terstenYazdir(str);

        }

        private static void terstenYazdir(String str) {
            String kelimeninTersi = "";

            for (int i =str.length()-1; i >=0 ; i--) {
                kelimeninTersi+=str.charAt(i);


            }

            System.out.println(kelimeninTersi);
        }
    }


