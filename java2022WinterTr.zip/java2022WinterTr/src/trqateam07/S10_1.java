package trqateam07;

import java.util.Scanner;

public class S10_1 {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("Lutfen iki rakam girin");

        int sayi1 = scan.nextInt();
        int sayi2 = scan.nextInt();

        int toplam= 0;


        if (sayi1 < sayi2) {
            for (int i = sayi1; i <= sayi2; i++) {
               toplam+=i;

            }
            System.out.println(toplam);
        } else {
            for (int i = sayi2; i <= sayi1; i++) {
                toplam+=i;

            }
            System.out.println(toplam);


        }

    }
}
