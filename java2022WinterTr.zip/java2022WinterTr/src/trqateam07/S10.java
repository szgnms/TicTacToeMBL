package trqateam07;

import java.util.Scanner;

public class S10 {
    public static void main(String[] args) {

        Scanner scan=new Scanner(System.in);
        System.out.println("Lutfen iki rakam girin");
        int sayi1=scan.nextInt();
        int sayi2=scan.nextInt();
        int buyukSayi= sayi1> sayi2? sayi1: sayi2;
        int kucukSayi= sayi2< sayi1? sayi2: sayi1;
        int toplam= 0;

        System.out.println(buyukSayi);
        System.out.println(kucukSayi);



        for ( ;kucukSayi <=buyukSayi; kucukSayi++) {

            toplam+=kucukSayi;
            
        }
        System.out.println(toplam);
    }
}
