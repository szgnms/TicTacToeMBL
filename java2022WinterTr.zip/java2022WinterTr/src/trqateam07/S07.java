package tr_qa_team07;

import java.util.Scanner;

public class S07 {
    public static void main(String[] args) {

        // Soru 7 ) Interview Question
        // Kullanicidan bir String isteyin ve Stringi bir methot ile tersten yazdirin.

        Scanner scan = new Scanner(System.in);
        System.out.println("Lutfen bir kelime giriniz");

        String str= scan.next();

        String terstenKelime = terstenYazdirma(str);

        System.out.println("Girdiginiz kelimenin tersten yazilisi : " + terstenKelime);
    }

    private static String terstenYazdirma(String str) {
        String terstenKelime="";
        for (int i = str.length()-1; i >= 0; i--) {
            terstenKelime+= str.charAt(i);
        } return terstenKelime;

    }

}