package trqateam07;

import java.util.Scanner;

public class AsalCarpan01 {
    static int bolen=0;
static boolean isAsal=true;

    public static void main(String[] args) {




    Scanner scanner = new Scanner(System.in);
    System.out.println("sayi girniz");
    int sayi= scanner.nextInt();

    asalcarpan(sayi);






   }

    private static void asalcarpan(int sayi) {
        for (int i = 2; i <=sayi ; i++) {
            if (sayi%i==0){
               bolen=i;
               asalMi(bolen);
            }

        }
    }

    private static boolean asalMi(int bolen) {
        for (int i = 2; i <bolen ; i++) {
            if (bolen%i!=0){
                isAsal=true;
            }

        }

    }
}
