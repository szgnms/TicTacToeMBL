package day11_stringManipulation;

import java.util.Scanner;

public class C03_equalsIgnoreCase {
    public static void main(String[] args) {

        Scanner scan= new Scanner(System.in);
        System.out.println("Derse Katilmak ister misiniz? \nEvet veya Hayir yaziniz");
        String cevap=scan.next();

        if (cevap.equalsIgnoreCase("evet")) {
            System.out.println("cevabınız : " + cevap + " derse katilimizi alinmisitr");
        } else if (cevap.equalsIgnoreCase("hayir")) {
            System.out.println("cevabınız : " + cevap + " sonraki derslerimzie bakleriz");
        } else {
            System.out.println("Lutfen evet veya hayir yaziniz");


        }

            String isim= null;
        System.out.println(isim.length());




    }
}
