package day21_arrays;

public class C01_Arrays {

    public static void main(String[] args) {

        int arr1[]={1,3,5};
        int[] arr2={2,4,6};
        double[] arr3={1.2};

        System.out.println(arr3);


    int arr7[]= new int[5];


    }
}
