package day17_forLoop;

import com.sun.tools.javac.Main;

public class C01_SonsuzDongu {
    public static void main(String[] args) {


        for (int i = 0; i>=0 ; i++) {
            System.out.println(i);
        }


    }



}
