package day17_forLoop;

import java.util.Scanner;

public class C05_ForLoop {
    public static void main(String[] args) {

        //Scanner scan = new Scanner(System.in);
        //System.out.println("lutfen sayi giriniz");

        int sayi=57;

        for (int i = 1; i <=sayi ; i++) {

            if (i%3==0){
                System.out.print(i+ " ");
            }

        }

    }
}
