package day16_methodCreation;

public class C02_Overloading {
    public static void main(String[] args) {




        String str= "Bu da gecer ya Huu";
        System.out.println(str.indexOf("d"));
        System.out.println(str.indexOf("a",5));
        System.out.println(str.indexOf('a',5));








    }
}
