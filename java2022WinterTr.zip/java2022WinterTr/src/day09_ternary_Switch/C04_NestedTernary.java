package day09_ternary_Switch;

public class C04_NestedTernary {
    public static void main(String[] args) {

        int sayi =121;

        if (sayi>=0){
            if (sayi%2==0){
                System.out.println("cift pozitif");
            }else{
                System.out.println("tek pozitif");
            }
        }else {
            if (sayi<100){
                System.out.println("negatif -100 kucuk");
            }else {
                System.out.println("negatif -100 buyuk");
            }
        }





           String sonuc =   sayi>=0 ?
                   (sayi%2==0 ?  "pozitif cift" : "pozitif tek") :
                   (sayi<-100 ?  "-100 den kucuk negatif" : "-100 den buyuk negatif");


            System.out.println(sonuc);






    }
}
