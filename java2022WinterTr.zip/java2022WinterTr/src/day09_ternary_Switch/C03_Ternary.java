package day09_ternary_Switch;

public class C03_Ternary {
    public static void main(String[] args) {

        int sayi=0;

       String sonuc= sayi>=100 ? "3 basamakli veya daha buyuk": "3 ten az basamkali";


        System.out.println(sonuc);

    }


}
