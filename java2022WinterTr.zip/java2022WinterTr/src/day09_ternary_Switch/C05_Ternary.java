package day09_ternary_Switch;

public class C05_Ternary {
    public static void main(String[] args) {

        int sayi=-20;

       int sonuc = sayi >= 0 ? sayi : ((-1)*sayi);
        System.out.println(sonuc);

    }
}
