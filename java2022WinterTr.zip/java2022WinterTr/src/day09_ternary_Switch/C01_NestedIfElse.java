package day09_ternary_Switch;

import java.util.Scanner;

public class C01_NestedIfElse {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("4 basamkli bir sayi gir");
        int sayi = scan.nextInt();


        if (sayi < 1000 || sayi > 9999) {
            System.out.println("4 basamkli bir sayi gir");
        } else if (sayi % 5 == 0) {
            if (sayi % 10 == 0) {
                System.out.println("5`e bolunene cift sayi");
            } else {
                System.out.println("5`e bolunene tek sayi");
            }


        } else {
            System.out.println("tekrar deneyin");
        }
    }

}

