package day03_scanner;

import java.util.Scanner;

public class C05_Scanner {
    public static void main(String[] args) {

        Scanner Scan = new Scanner(System.in);
        System.out.println("Lutfen cemberin yaricapini giriniz");
        double yaricap= Scan.nextDouble();

        System.out.println("Girdiginiz yari cap : " + yaricap);
        System.out.println("cemberin cevresi : " +2*3.14+yaricap);
        System.out.println("dairenizin alanı : " +3.14* yaricap*yaricap);


    }
}
