package day03_scanner;

import java.util.Scanner;

public class C06_Scanner {
    public static void main(String[] args) {

        Scanner scan=new Scanner(System.in);
        System.out.println("Lutfen isminizi yaziniz");
        String isin = scan.nextLine();
        System.out.println("LUtfen soyisminiz giriniz");
        String soyisim= scan.nextLine();

        System.out.println("Isım - Soyisim : " + isin + " " +soyisim );



    }
}
