package day03_scanner;

public class C01_Variables {
    public static void main(String[] args) {

        String okulIsmi="Yildiz Koleji";
        System.out.println(okulIsmi);

        char ilkHarf;
        ilkHarf='H';
        System.out.println(ilkHarf);

        int sayi1=10, sayi2=20;
        System.out.println(sayi1+sayi2);


        String isim="Nezir";
        String soyIsim="Yildiz";

        System.out.println("Isminiz : " + isim);
        System.out.println("Soyismiiniz : " +soyIsim);


        short sayi3=20;
        double sayi4=30;
        System.out.println("iki sayinin toplamı :" +(sayi4+sayi3));

        int sayi5=20;
        char harf='a';
        System.out.println(sayi5+harf);

int sayi6='a';
        System.out.println(sayi6);






    }
}
