package day19_doWhileLoop;

import java.util.Scanner;

public class C02_WhileLoop {
    public static void main(String[] args) {

        // kullancidan bir sayi alin ve bu sayinin rakamlari toplamini yazdirin

        Scanner scan=new Scanner(System.in);
        System.out.println("sayi girin");
        int input=scan.nextInt();

        int rakam=0;
        int rakamlarToplani=0;

        while (input>0){
            rakam=input%10;
            rakamlarToplani+=rakam;
            input/=10;

        }

        System.out.println("rakamlar toplam  "+rakamlarToplani);


    }
}
