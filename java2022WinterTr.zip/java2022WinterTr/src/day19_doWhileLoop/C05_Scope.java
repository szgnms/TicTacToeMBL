package day19_doWhileLoop;



public class C05_Scope {

    static String kurs="Java";
    int level=10;


    public static void main(String[] args) {

        System.out.println(kurs);
       // System.out.println(level);

        for (int i = 0; i < 10; i++) {
            System.out.println(i);
        }

    }

    public static void method1() {
        System.out.println(kurs);
        //System.out.println(level);

    }

    public void method2() {
        System.out.println(kurs);
        System.out.println(level);


    }
}