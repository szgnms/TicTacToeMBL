package day02_variables;

public class C01_Variables {
    public static void main(String[] args) {

        System.out.println("Hello World yazdiran Javayi halleder");

        int level=1;

        System.out.println("level " + level);


        boolean ogrenciMi= true;

        boolean yagisVarMi= false;

        System.out.println(ogrenciMi);

        char ozelSembol='&';
        char sayi='2';

        System.out.println(ozelSembol);



    }
}
