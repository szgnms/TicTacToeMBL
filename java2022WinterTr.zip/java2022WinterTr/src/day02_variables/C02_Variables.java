package day02_variables;

public class C02_Variables {
    public static void main(String[] args) {

        String okulIsmi;


        okulIsmi="Yildiz Koleji";

        System.out.println(okulIsmi);

        okulIsmi="Star Koleji";

        System.out.println(okulIsmi);


        okulIsmi="Java Koleji";

        System.out.println(okulIsmi);
    }
}
