package day02_variables;

public class C03_Variables {
    public static void main(String[] args) {


        String ogrenciISmi="Melih";

        ogrenciISmi="Furkan";

        String isim,soyisim,dogumYeri;
        isim="Nihad";
        soyisim="ozel";
        dogumYeri="Ankara";

        System.out.println(dogumYeri);
        System.out.println(soyisim);


        String tcNo="12345678901";
        String hiclik="";

        String harf= "A";
        char harf2='A';


    }
}
