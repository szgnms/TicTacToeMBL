package day22_arrays;

import java.util.Arrays;

public class C06_BinarySearch {
    public static void main(String[] args) {

        int arr[] = {3, 5, 6, 1, 9, 45, 25, 4, 9, 0};

        int istenensayi =-10;

        Arrays.sort(arr);



        System.out.println(Arrays.toString(arr));
        System.out.println(Arrays.binarySearch(arr, istenensayi));




    }
}
