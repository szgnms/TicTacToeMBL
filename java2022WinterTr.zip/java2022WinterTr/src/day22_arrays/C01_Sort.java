package day22_arrays;

import java.util.Arrays;

import static java.util.Arrays.sort;

public class C01_Sort {
    public static void main(String[] args) {


        String arr[]={"S","M","A","T"};

        System.out.println(Arrays.toString(arr));


      Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));





    }
}
