package day20_scope_Arrays;

public class C01_InstanceVeriables {


    int sayi;
    String bransIsmi="Java";
    boolean okulAcikMi;

    public static void main(String[] args) {

        //sayi=10;

        C01_InstanceVeriables obj1 = new C01_InstanceVeriables();
        System.out.println(obj1.sayi);
        obj1.sayi=10;
        System.out.println(obj1.sayi);
        obj1.bransIsmi="SQL";


        C01_InstanceVeriables obj2 = new C01_InstanceVeriables();
        System.out.println(obj2.sayi);
        System.out.println(obj2.bransIsmi);



    }
}
