package day20_scope_Arrays;

public class C03_LocalVariables {
    public static void main(String[] args) {



        for (int i = 1; i <=10 ; i++) {
            int sayi=0;
            System.out.println(sayi+1);

        }

    }
}
