package day13_stringManipulation;

public class C03_Cte_Rte {
    public static void main(String[] args) {




        String str = "Javada hersey zamanla oturur";
        System.out.println(str.substring(500));





    }
}
